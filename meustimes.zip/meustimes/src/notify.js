import * as Notifications from 'expo-notifications';

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert: true, shouldPlaySound: true, shouldSetBadge: false }),
});

// Agenda um aviso 10 min antes. Devolve o id para poder cancelar depois.
export async function scheduleReminder(match, teamName) {
  const { status } = await Notifications.requestPermissionsAsync();
  if (status !== 'granted') return null;
  const when = new Date(match.date - 10 * 60 * 1000);
  if (when <= new Date()) return null;
  return Notifications.scheduleNotificationAsync({
    content: {
      title: 'Jogo já já',
      body: `${teamName} x ${match.opponent} começa em 10 minutos`,
    },
    trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: when },
  });
}

export const cancelReminder = (id) => Notifications.cancelScheduledNotificationAsync(id);
