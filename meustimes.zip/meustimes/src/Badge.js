import React from 'react';
import { Text, View } from 'react-native';
// Escudo provisório com a sigla. Troque por <Image source={{uri: team.logo}} /> quando ligar a API.
export default function Badge({ team, size = 52 }) {
  const w = team.name.split(' ');
  const txt = (w.length > 1 ? w.map((a) => a[0]).join('').slice(0, 3) : team.name.slice(0, 3)).toUpperCase();
  return (
    <View style={{ width: size, height: size * 1.05, backgroundColor: team.color, borderRadius: size / 4, borderBottomLeftRadius: size / 2, borderBottomRightRadius: size / 2, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ color: '#fff', fontWeight: '800', fontSize: size / 3.6 }}>{txt}</Text>
    </View>
  );
}
