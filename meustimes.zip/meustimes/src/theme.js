import { Platform } from 'react-native';
export const C = { bg: '#F3F5F0', ink: '#10231A', mute: '#5E6B63', line: '#D9DED5', card: '#FFFFFF', pitch: '#12372A' };
// Fonte limpa, sem instalar nada: Roboto Medium no Android, fonte do sistema no iPhone
export const F = Platform.select({ android: 'sans-serif-medium', default: 'System' });
