import React, { useState } from 'react';
import { Modal, Pressable, ScrollView, Text, TouchableOpacity, View, StyleSheet } from 'react-native';
import { C, F } from '../theme';
import { SPORTS, compsFor, liveFor, matches, st } from '../data';
import { tr, lab } from '../i18n';
import { scheduleReminder, cancelReminder } from '../notify';
import { LangBar } from './Login';

const LOC = { pt: 'pt-BR', en: 'en-US', es: 'es-ES' };
const TK = ['t0', 'news', 't1', 't2', 't3'];

export default function Home({ picks, user, lang, onLang, onReset, onLogout }) {
  const [sid, setSid] = useState(SPORTS[0].id);
  const [tab, setTab] = useState(0);
  const [comp, setComp] = useState(0);
  const [ti, setTi] = useState({});
  const [bells, setBells] = useState({});
  const [menu, setMenu] = useState(false);

  const sport = SPORTS.find((x) => x.id === sid);
  const teams = picks[sid];
  const team = teams[Math.min(ti[sid] || 0, teams.length - 1)];
  const cs = compsFor(sport, team);
  const fmt = (ms) => new Date(ms).toLocaleString(LOC[lang], { weekday: 'short', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

  const toggleBell = async (m) => {
    if (bells[m.id]) {
      await cancelReminder(bells[m.id]);
      setBells((b) => ({ ...b, [m.id]: null }));
    } else {
      const id = await scheduleReminder(m, team.name);
      if (id) setBells((b) => ({ ...b, [m.id]: id }));
    }
  };
  const pick = (id) => { setSid(id); setTab(0); setComp(0); };

  let body = null;
  if (tab === 0) {
    const L = liveFor(sport, team); // TODO: trocar por API de placar ao vivo
    body = (
      <>
        <View style={s.live}>
          <Text style={s.liveTag}>● {tr('live')}</Text>
          <Text style={s.meta}>{L.clock}</Text>
          <Text style={[s.match, { flex: 1, textAlign: 'right' }]}>{team.name} {L.a} – {L.b} {L.opp}</Text>
        </View>
        <Text style={s.h}>{tr('next')}</Text>
        {matches(sport, team).map((m) => (
          <View key={m.id} style={s.card}>
            <View style={{ flex: 1 }}>
              <Text style={s.match}>{m.home ? `${team.name} x ${m.opp}` : `${m.opp} x ${team.name}`}</Text>
              <Text style={s.meta}>{fmt(m.date)} · {cs[0] === 'ce' || cs[0] === 'cw' ? 'NBA' : lab(cs[0])}</Text>
            </View>
            <TouchableOpacity onPress={() => toggleBell(m)} hitSlop={12}>
              <Text style={{ fontSize: 24, opacity: bells[m.id] ? 1 : 0.3 }}>🔔</Text>
            </TouchableOpacity>
          </View>
        ))}
      </>
    );
  } else if (tab === 1) {
    body = (
      <>
        <Text style={s.h}>{tr('news')} · {team.name}</Text>
        {['n1', 'n2', 'n3'].map((k, i) => (
          <View key={k} style={s.card}>
            <View style={{ flex: 1 }}>
              <Text style={s.match}>{tr(k).replace('{t}', team.name)}</Text>
              <Text style={s.meta}>{i * 3 + 1}h</Text>
            </View>
          </View>
        ))}
      </>
    );
  } else if (tab === 2) {
    body = (
      <>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 12 }}>
          {cs.map((x, i) => (
            <TouchableOpacity key={x} onPress={() => setComp(i)} style={[s.chip, i === comp && s.chipOn]}>
              <Text style={{ color: i === comp ? '#fff' : C.ink, fontWeight: '600' }}>{lab(x)}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
        <View style={s.tbl}>
          <View style={s.trow}><Text style={[s.th, { flex: 1, textAlign: 'left' }]}>{tr('team')}</Text><Text style={s.th}>{tr('g')}</Text><Text style={s.th}>{tr('w')}</Text><Text style={s.th}>Pts</Text></View>
          {st(sport, team, Math.min(comp, cs.length - 1)).map((r, i) => (
            <View key={r.n} style={[s.trow, r.n === team.name && { backgroundColor: team.color + '22' }]}>
              <Text style={[s.td, { flex: 1, textAlign: 'left' }]}>{i + 1}. {r.n}</Text>
              <Text style={s.td}>{r.j}</Text><Text style={s.td}>{r.v}</Text><Text style={[s.td, { fontWeight: '800' }]}>{r.pts}</Text>
            </View>
          ))}
        </View>
      </>
    );
  } else if (tab === 3) {
    body = (
      <>
        <Text style={s.h}>{tr('season')}</Text>
        <View style={s.sg}>
          {tr('st_' + sid).split('|').map((x, i) => {
            const v = ((i * 13 + 7) % 40) + 10;
            return (
              <View key={x} style={s.sc}>
                <Text style={s.meta}>{x}</Text>
                <Text style={[s.big, { color: team.color }]}>{v}</Text>
                <View style={{ height: 4, borderRadius: 2, width: `${Math.min(100, v * 2)}%`, backgroundColor: team.color }} />
              </View>
            );
          })}
        </View>
      </>
    );
  } else {
    body = (
      <>
        <Text style={s.h}>{tr('about')} {team.name}</Text>
        <View style={s.card}><Text style={s.meta}>{tr('aboutTxt')}</Text></View>
      </>
    );
  }

  const Item = ({ k, onPress, tag }) => (
    <TouchableOpacity style={s.mi} onPress={onPress}>
      <Text style={s.miTxt}>{tr(k)}</Text>
      {tag ? <Text style={s.vip}>{tag}</Text> : <Text style={{ color: C.mute }}>›</Text>}
    </TouchableOpacity>
  );

  return (
    <View style={s.wrap}>
      <View style={[s.header, { backgroundColor: team.color }]}>
        <View style={s.bar}>
          <Text style={s.brand}>Torcida</Text>
          <TouchableOpacity onPress={() => setMenu(true)} hitSlop={12}><Text style={{ color: '#fff', fontSize: 26 }}>☰</Text></TouchableOpacity>
        </View>
        <View style={s.sports}>
          {SPORTS.map((x) => (
            <TouchableOpacity key={x.id} onPress={() => pick(x.id)} style={[s.sportBtn, x.id === sid && s.sportOn]}>
              <Text style={[s.sportTxt, x.id === sid && { color: '#111' }]}>{x.emoji} {tr(x.id)}</Text>
            </TouchableOpacity>
          ))}
        </View>
        {teams.length > 1 && (
          <View style={[s.sports, { marginTop: 8 }]}>
            {teams.map((x, i) => (
              <TouchableOpacity key={x.name} onPress={() => { setTi({ ...ti, [sid]: i }); setComp(0); }} style={[s.sportBtn, x === team && s.sportOn]}>
                <Text style={[s.sportTxt, x === team && { color: '#111' }]}>{x.name}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
        <Text style={s.team}>{team.name}</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {TK.map((k, i) => (
            <TouchableOpacity key={k} onPress={() => { setTab(i); setComp(0); }} style={[s.tab, tab === i && s.tabOn]}>
              <Text style={[s.tabTxt, tab === i && { opacity: 1 }]}>{tr(k)}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 60 }}>{body}</ScrollView>

      <Modal visible={menu} transparent animationType="fade" onRequestClose={() => setMenu(false)}>
        <Pressable style={s.ov} onPress={() => setMenu(false)}>
          <Pressable style={s.panel}>
            <View style={s.who}>
              <View style={s.avatar}><Text style={{ color: '#fff', fontWeight: '800' }}>{user.name[0]}</Text></View>
              <View><Text style={s.miTxt}>{user.name}</Text><Text style={s.meta}>Google</Text></View>
            </View>
            <Item k="acc" onPress={() => {}} />
            <Item k="nt" onPress={() => {}} />
            <Item k="vip" tag="VIP" onPress={() => {}} />
            <Item k="chg" onPress={() => { setMenu(false); onReset(); }} />
            <Text style={s.lbl}>{tr('lang')}</Text>
            <LangBar lang={lang} onLang={onLang} />
            <View style={{ height: 14 }} />
            <Item k="out" onPress={() => { setMenu(false); onLogout(); }} />
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: C.bg },
  header: { paddingTop: 48, paddingHorizontal: 16 },
  bar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  brand: { color: '#fff', fontSize: 18, fontFamily: F },
  sports: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 6 },
  sportBtn: { paddingVertical: 8, paddingHorizontal: 10, borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.18)' },
  sportOn: { backgroundColor: '#fff' },
  sportTxt: { color: '#fff', fontWeight: '600', fontSize: 13 },
  team: { color: '#fff', fontSize: 30, fontFamily: F, marginVertical: 14, letterSpacing: -0.5 },
  tab: { paddingVertical: 12, marginRight: 22, borderBottomWidth: 3, borderColor: 'transparent' },
  tabOn: { borderColor: '#fff' },
  tabTxt: { color: '#fff', opacity: 0.65, fontWeight: '700', fontSize: 15 },
  h: { color: C.ink, fontSize: 20, fontFamily: F, marginBottom: 10 },
  card: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderRadius: 10, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: C.line },
  live: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: C.card, borderRadius: 10, padding: 12, marginBottom: 16, borderWidth: 1, borderColor: C.line, borderLeftWidth: 4, borderLeftColor: '#E5322D' },
  liveTag: { color: '#E5322D', fontWeight: '800', fontSize: 12 },
  match: { color: C.ink, fontSize: 15, fontWeight: '600' },
  meta: { color: C.mute, fontSize: 14, marginTop: 2 },
  chip: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: 16, borderWidth: 1, borderColor: C.line, backgroundColor: C.card, marginRight: 8 },
  chipOn: { backgroundColor: C.pitch, borderColor: C.pitch },
  tbl: { backgroundColor: C.card, borderRadius: 10, borderWidth: 1, borderColor: C.line, overflow: 'hidden' },
  trow: { flexDirection: 'row', paddingVertical: 11, paddingHorizontal: 12, borderBottomWidth: 1, borderColor: C.line },
  th: { width: 40, textAlign: 'right', color: C.mute, fontWeight: '700' },
  td: { width: 40, textAlign: 'right', color: C.ink },
  sg: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  sc: { width: '48.5%', backgroundColor: C.card, borderRadius: 10, borderWidth: 1, borderColor: C.line, padding: 14, gap: 6 },
  big: { fontSize: 26, fontFamily: F },
  ov: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', alignItems: 'flex-end' },
  panel: { width: '78%', maxWidth: 320, height: '100%', backgroundColor: C.bg, padding: 20, paddingTop: 56 },
  who: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingBottom: 18, borderBottomWidth: 1, borderColor: C.line },
  avatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: C.pitch, alignItems: 'center', justifyContent: 'center' },
  mi: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 15, borderBottomWidth: 1, borderColor: C.line },
  miTxt: { color: C.ink, fontSize: 16 },
  vip: { color: '#B7791F', fontSize: 11, fontWeight: '800', borderWidth: 1, borderColor: '#B7791F', borderRadius: 4, paddingHorizontal: 5, paddingVertical: 1 },
  lbl: { color: C.mute, fontSize: 12, marginTop: 22, textTransform: 'uppercase', letterSpacing: 1 },
});
