import React, { useState } from 'react';
import { ScrollView, Text, TouchableOpacity, View, StyleSheet } from 'react-native';
import { C, F } from '../theme';
import { tr } from '../i18n';
import Badge from '../Badge';

export default function PickTeam({ sport, step, total, onConfirm }) {
  const [sel, setSel] = useState([]);
  const toggle = (t) =>
    setSel((cur) => (cur.some((x) => x.name === t.name) ? cur.filter((x) => x.name !== t.name) : cur.length < 3 ? [...cur, t] : cur));
  return (
    <View style={s.wrap}>
      <View style={s.head}>
        <Text style={s.step}>{step} {tr('of')} {total} · {tr('multi')}</Text>
        <Text style={s.title}>{sport.emoji} {tr('pick_' + sport.id)}</Text>
      </View>
      <ScrollView contentContainerStyle={{ paddingBottom: 120 }}>
        {sport.groups.map((g) => (
          <View key={g.title}>
            <Text style={s.group}>{tr(g.title)}</Text>
            <View style={s.grid}>
              {g.teams.map((t) => {
                const on = sel.some((x) => x.name === t.name);
                return (
                  <TouchableOpacity key={t.name} style={[s.tm, on && { borderColor: t.color, backgroundColor: t.color + '1F' }]} onPress={() => toggle(t)}>
                    <Badge team={t} />
                    <Text style={s.name} numberOfLines={2}>{t.name}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        ))}
      </ScrollView>
      <View style={s.foot}>
        <TouchableOpacity disabled={!sel.length} style={[s.btn, !sel.length && { opacity: 0.35 }]} onPress={() => onConfirm(sel)}>
          <Text style={s.btnText}>{tr('ok')}{sel.length ? ` (${sel.length})` : ''}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: C.bg },
  head: { paddingHorizontal: 20, paddingTop: 56, paddingBottom: 8, alignItems: 'center' },
  step: { color: C.mute, fontSize: 14 },
  title: { color: C.ink, fontSize: 26, fontFamily: F, marginTop: 4, textAlign: 'center' },
  group: { color: C.mute, fontSize: 15, fontWeight: '600', marginTop: 18, marginBottom: 8, paddingHorizontal: 20 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 11, gap: 10 },
  tm: { width: '30.5%', minHeight: 118, alignItems: 'center', gap: 8, paddingVertical: 14, paddingHorizontal: 6, borderRadius: 18, backgroundColor: C.card, borderWidth: 2, borderColor: C.line },
  name: { color: C.ink, fontSize: 13, fontWeight: '600', textAlign: 'center' },
  foot: { position: 'absolute', left: 0, right: 0, bottom: 0, padding: 20, backgroundColor: C.bg, borderTopWidth: 1, borderColor: C.line },
  btn: { backgroundColor: C.pitch, borderRadius: 12, paddingVertical: 16, alignItems: 'center' },
  btnText: { color: '#fff', fontSize: 17, fontWeight: '700' },
});
