import React from 'react';
import { Text, TouchableOpacity, View, StyleSheet } from 'react-native';
import { C, F } from '../theme';
import { tr } from '../i18n';

export function LangBar({ lang, onLang, dark }) {
  return (
    <View style={{ flexDirection: 'row', gap: 6, marginTop: 18 }}>
      {['pt', 'en', 'es'].map((l) => (
        <TouchableOpacity key={l} onPress={() => onLang(l)} style={[s.lg, { borderColor: dark ? '#fff' : C.mute, opacity: l === lang ? 1 : 0.5 }]}>
          <Text style={{ color: dark ? '#fff' : C.ink, fontWeight: '700' }}>{l.toUpperCase()}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

export default function Login({ onLogin, lang, onLang }) {
  // TODO: trocar por login real com Google (Firebase Auth + expo-auth-session).
  return (
    <View style={s.wrap}>
      <Text style={s.title}>Torcida</Text>
      <Text style={s.sub}>{tr('tag')}</Text>
      <TouchableOpacity style={s.btn} onPress={() => onLogin({ name: tr('fan') })}>
        <Text style={s.btnText}>{tr('go')}</Text>
      </TouchableOpacity>
      <LangBar lang={lang} onLang={onLang} dark />
    </View>
  );
}

const s = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: C.pitch, justifyContent: 'flex-end', padding: 28, paddingBottom: 56 },
  title: { color: '#fff', fontSize: 44, fontFamily: F, letterSpacing: -1 },
  sub: { color: '#BFD0C6', fontSize: 17, lineHeight: 24, marginTop: 12, marginBottom: 36 },
  btn: { backgroundColor: '#fff', borderRadius: 12, paddingVertical: 16, alignItems: 'center' },
  btnText: { color: C.ink, fontSize: 17, fontWeight: '700' },
  lg: { flex: 1, borderWidth: 1, borderRadius: 8, paddingVertical: 9, alignItems: 'center' },
});
