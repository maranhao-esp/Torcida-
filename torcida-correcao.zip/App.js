import React from 'react';
import { ScrollView, Text } from 'react-native';

// Se o app falhar ao abrir, mostra o erro na tela em vez de fechar sozinho.
let Main = null;
let loadError = null;
try {
  Main = require('./src/Main').default;
} catch (e) {
  loadError = e;
}

const Show = ({ e }) => (
  <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={{ padding: 24, paddingTop: 60 }}>
    <Text style={{ fontWeight: '700', fontSize: 18 }}>Erro ao abrir o app</Text>
    <Text selectable style={{ marginTop: 12 }}>{String((e && (e.stack || e.message)) || e)}</Text>
  </ScrollView>
);

class Boundary extends React.Component {
  state = { error: null };
  static getDerivedStateFromError(error) { return { error }; }
  render() { return this.state.error ? <Show e={this.state.error} /> : this.props.children; }
}

export default function App() {
  return loadError ? <Show e={loadError} /> : <Boundary><Main /></Boundary>;
}
