import React, { useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SPORTS } from './data';
import { setLang as setI18n } from './i18n';
import Login from './screens/Login';
import PickTeam from './screens/PickTeam';
import Home from './screens/Home';

const KEY = 'torcida:v2';

export default function Main() {
  const [ready, setReady] = useState(false);
  const [user, setUser] = useState(null);
  const [picks, setPicks] = useState({}); // { soccer: [times], basketball: [times], ... }
  const [step, setStep] = useState(0);
  const [lang, setLangState] = useState('pt');

  const changeLang = (l) => { setI18n(l); setLangState(l); };

  useEffect(() => {
    AsyncStorage.getItem(KEY)
      .then((raw) => {
        if (raw) {
          const d = JSON.parse(raw);
          setUser(d.user);
          setPicks(d.picks || {});
          setStep(Object.keys(d.picks || {}).length);
          if (d.lang) changeLang(d.lang);
        }
      })
      .catch(() => {})
      .finally(() => setReady(true));
  }, []);

  const save = (u, p, l) => AsyncStorage.setItem(KEY, JSON.stringify({ user: u, picks: p, lang: l })).catch(() => {});

  if (!ready) return <View style={{ flex: 1, justifyContent: 'center' }}><ActivityIndicator /></View>;

  let screen;
  if (!user) {
    screen = <Login lang={lang} onLang={(l) => { changeLang(l); save(user, picks, l); }} onLogin={(u) => { setUser(u); save(u, picks, lang); }} />;
  } else if (step < SPORTS.length) {
    const sport = SPORTS[step];
    screen = (
      <PickTeam key={sport.id} sport={sport} step={step + 1} total={SPORTS.length}
        onConfirm={(teams) => { const p = { ...picks, [sport.id]: teams }; setPicks(p); setStep(step + 1); save(user, p, lang); }} />
    );
  } else {
    screen = (
      <Home picks={picks} user={user} lang={lang}
        onLang={(l) => { changeLang(l); save(user, picks, l); }}
        onReset={() => { setPicks({}); setStep(0); save(user, {}, lang); }}
        onLogout={() => { setUser(null); save(null, picks, lang); }} />
    );
  }
  // key={lang} força a tela a redesenhar quando o idioma muda
  return <View style={{ flex: 1 }} key={lang}><StatusBar style="light" />{screen}</View>;
}
