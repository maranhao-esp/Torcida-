// Carrega as notificações só quando precisa. Se o módulo falhar, o app continua abrindo.
let N = null;
function load() {
  if (N) return N;
  try {
    N = require('expo-notifications');
    N.setNotificationHandler({
      handleNotification: async () => ({ shouldShowAlert: true, shouldShowBanner: true, shouldShowList: true, shouldPlaySound: true, shouldSetBadge: false }),
    });
  } catch (e) {
    N = null;
  }
  return N;
}

// Agenda um aviso 10 min antes. Devolve o id para poder cancelar depois.
export async function scheduleReminder(match, teamName) {
  const Notifications = load();
  if (!Notifications) return null;
  try {
    const { status } = await Notifications.requestPermissionsAsync();
    if (status !== 'granted') return null;
    const when = new Date(match.date - 10 * 60 * 1000);
    if (when <= new Date()) return null;
    return await Notifications.scheduleNotificationAsync({
      content: { title: 'Torcida', body: `${teamName} x ${match.opp} começa em 10 minutos` },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: when },
    });
  } catch (e) {
    return null;
  }
}

export async function cancelReminder(id) {
  const Notifications = load();
  if (!Notifications) return;
  try { await Notifications.cancelScheduledNotificationAsync(id); } catch (e) {}
}
